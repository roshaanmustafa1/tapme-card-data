<template>
  <div class="btn-black">
    <button class="btn btn-sm btn-outline-dark">btn black</button>
  </div>
</template>
